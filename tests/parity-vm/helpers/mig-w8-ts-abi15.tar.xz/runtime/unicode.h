#ifndef TREE_SITTER_UNICODE_H_
#define TREE_SITTER_UNICODE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <limits.h>
#include <stdint.h>

#define U_EXPORT
#define U_EXPORT2
#include "utf8.h"
#include "utf16.h"
#include "endian.h"

#define U16_NEXT_LE(s, i, length, c) UPRV_BLOCK_MACRO_BEGIN { \
    (c)=le16toh((s)[(i)++]); \
    if(U16_IS_LEAD(c)) { \
        uint16_t __c2; \
        if((i)!=(length) && U16_IS_TRAIL(__c2=(s)[(i)])) { \
            ++(i); \
            (c)=U16_GET_SUPPLEMENTARY((c), __c2); \
        } \
    } \
} UPRV_BLOCK_MACRO_END

#define U16_NEXT_BE(s, i, length, c) UPRV_BLOCK_MACRO_BEGIN { \
    (c)=be16toh((s)[(i)++]); \
    if(U16_IS_LEAD(c)) { \
        uint16_t __c2; \
        if((i)!=(length) && U16_IS_TRAIL(__c2=(s)[(i)])) { \
            ++(i); \
            (c)=U16_GET_SUPPLEMENTARY((c), __c2); \
        } \
    } \
} UPRV_BLOCK_MACRO_END

static const int32_t TS_DECODE_ERROR = U_SENTINEL;

static inline uint32_t ts_decode_utf8(
  const uint8_t *string,
  uint32_t length,
  int32_t *code_point
) {
  uint32_t i = 0;
  U8_NEXT(string, i, length, *code_point);
  return i;
}

static inline uint32_t ts_decode_utf16_le(
  const uint8_t *string,
  uint32_t length,
  int32_t *code_point
) {
  if (length < 2) {
    *code_point = TS_DECODE_ERROR;
    return length;
  }
  uint32_t i = 0;
  // length is in bytes; U16_NEXT indexes into uint16_t*, so its length
  // parameter must be in code units (length / 2), not bytes.
  U16_NEXT_LE(((uint16_t *)string), i, length / 2, *code_point);
  return i * 2;
}

static inline uint32_t ts_decode_utf16_be(
  const uint8_t *string,
  uint32_t length,
  int32_t *code_point
) {
  if (length < 2) {
    *code_point = TS_DECODE_ERROR;
    return length;
  }
  uint32_t i = 0;
  // length is in bytes; U16_NEXT indexes into uint16_t*, so its length
  // parameter must be in code units (length / 2), not bytes.
  U16_NEXT_BE(((uint16_t *)string), i, length / 2, *code_point);
  return i * 2;
}

#ifdef __cplusplus
}
#endif

#endif  // TREE_SITTER_UNICODE_H_
